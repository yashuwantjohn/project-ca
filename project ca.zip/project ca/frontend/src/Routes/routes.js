import LoginPage from "../pages/LoginPage";
import Login from "../component/auth/Login";
import Home from "../pages/Home";
export {Login,LoginPage,Home};